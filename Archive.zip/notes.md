792x528 carousel icindeki image larin sizeleri 

https://unsplash.it/792/528

https://picsum.photos/792/528?random=1

523*349

categories first row 
https://picsum.photos/523/349?random=1


categories 2nd row and all the way down 
https://picsum.photos/388/259?random=1